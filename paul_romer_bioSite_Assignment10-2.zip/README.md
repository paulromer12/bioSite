# bioSite
bioSite project for csd340

# CSD 340 Web Development with HTML and CSS

## Contributors
* John Woods
* Paul Romer

# TODO before final submission
- [x] Increase size of text on the hobbies page
- [x] Change the text color to stand out a little more
- [x] Organize and document the code 
- [x] Get a better picture of the pie on the hobbies page
- [x] Make sure I have an external link
- [x] white spot on about page? (rogue hr tag inbetween divs)
- [x] adjusted spacing and added visit to the external link on about page
- [x] rounded cards to match images
- [x] double check html and css validation
    - [x] hobbies
    - [x] about
    - [x] style
    - [x] index
- [x] check that the final github pages site is fully working
- [x] create final submission doc